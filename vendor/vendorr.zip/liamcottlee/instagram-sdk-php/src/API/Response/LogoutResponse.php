<?php

namespace Instagram\API\Response;

class LogoutResponse extends BaseResponse {



}