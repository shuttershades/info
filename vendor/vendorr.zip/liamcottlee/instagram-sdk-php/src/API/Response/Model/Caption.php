<?php

namespace Instagram\API\Response\Model;

class Caption extends Comment {

}