<?php
class JsonMapperTest_PlainObject
{
    /**
     * @var string
     */
    public $pStr;
}
?>
