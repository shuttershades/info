<?php
namespace namespacetest\model;

class UserList extends \ArrayObject
{
}

?>
