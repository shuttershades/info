What is the expected behavior?

What is the actual behavior?

What steps will reproduce the problem?
